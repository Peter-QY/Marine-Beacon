#ifndef _SERVO_H
#define _SERVO_H

#include "sys.h"
#include "delay.h"



void Servo1_Init(void);
void Servo2_Init(void);
void Servo3_Init(void);
void Servo4_Init(void);


void SERVO1_CONTRAL(int16_t speed,uint8_t num);
void SERVO2_CONTRAL(int16_t speed,uint8_t num);
void SERVO3_CONTRAL(int16_t speed,uint8_t num);
void SERVO4_CONTRAL(int16_t speed,uint8_t num);
#endif
